var express = require('express');
var router = express.Router();
var axios = require('axios');


var employeeData;

/* GET home page. */
router.get('/', paginate(), (req, res) => {
  res.render('index', { title: 'Express', employeeData: res.paginatedResult, prevPage: res.paginatedResult.prevPage, nextPage:res.paginatedResult.nextPage, limit: res.paginatedResult.limit, currentPage: res.paginatedResult.page });
});

/* middleware function for paginating the employee data */
function paginate() {
  axios.get('http://dummy.restapiexample.com/api/v1/employees')
    .then(response => {
      employeeData = response.data;
      employeeData = employeeData.data;
    })
    .catch(error => {
      console.log(error);
    });
  return (req, res, next) => {
    const page = parseInt(req.query.page);
    let limit = parseInt(req.query.limit);

    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    const results = {};

    if (startIndex > 0) {
      results.previous = {
        page: page - 1,
        limit: limit
      }
    }

    if (endIndex < employeeData.length) {
      results.next = {
        page: page + 1,
        limit: limit
      }
    }

    /* creating a page number array for pagination */
    const paginationArray = [];
    const maxRangeOfPagination = Math.ceil(employeeData.length / limit);
    for(let i = page - 1; i < page + 4 && i < maxRangeOfPagination; i++) paginationArray.push({id: i + 1, limit: limit});

    results.result = employeeData.slice(startIndex, endIndex);
    results.limit = limit;
    results.prevPage = page - 1;
    results.nextPage = page + 1;
    results.range = paginationArray;
    results.page = page;
    res.paginatedResult = results;
    next();
  }
}

module.exports = router;
